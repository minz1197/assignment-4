function run(){
   
    var t="Javascript";
     
     var text="";
   
    
      for(var x of t){
         
          
              text= text + x;
              document.write("<b>"+text+"</b><br>");
         
      }
 
  }